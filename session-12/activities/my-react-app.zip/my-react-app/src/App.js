import React from "react";
import DateInputComponent from "./components/DateInputComponent.js";

function App() {
  return <DateInputComponent />;
}

export default App;
