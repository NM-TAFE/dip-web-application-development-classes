// Slide one is babel slide

// ------ Stage 1 ------ Slides 1,2 & 3
// 1) Import the React and ReactDOM libraries
import React from "react";
import ReactDOM from "react-dom/client";

// Fix error - slide 12
import "./style.css";

// // 2) Get a reference to the div with ID root
// const element = document.getElementById("root");

// // 3) Tell React to take control of that element
// const root = ReactDOM.createRoot(element);

// // // 4) Create a component
// function MyCustomApp() {
//   const message = "Hello from the string";
//   //   // const message = { message: "Hello from the object" };
//   //  return { message }; // Error
//   //   return <h1>{message}</h1>;
// }

// // Class Component (less common now)
// class MyCustomApp extends React.Component {
//   render() {
//     return <h1>Hello, World!</h1>;
//   }
// }

// 5) Show the component on the screen
// root.render(<MyCustomApp />);

// ----- stage 2 -----Slide 7
// function CurrentTime() {
//   const now = new Date().toLocaleTimeString();
//   <p>Current time: {now}</p>; //! no return
// }

// ----- Stage 2 ------
// root.render(<CurrentTime />);

// ----- stage 3 ----- Slide 5
// function CurrentTime() {
//   const now = new Date().toLocaleTimeString();
//   return <p>Current time: {now}</p>;
// }

// function DisplayDate() {
//   const today = new Date();
//   return <p>Today's date is: {today.toDateString()}</p>;
// }

// ----- Stage 3 ------
// root.render(<CurrentTime /> <DisplayDate/>);  // Review error
// root.render(
//   <>
//     <CurrentTime /> <DisplayDate />
//   </>
// ); // Fix error

// ----  Stage 4 --- Atrtributes
// function MyInput() {
//   // return <input type="number" />;
//   // return <input type="number" min={5} />;

//   // Slide 12
//   return <input style={{ border: "3px solid red" }} type="number" min={5} />;
// }

// Slide 11
// function MyOtherInput() {
//   return <input type="text" />;
//   return <input type="text" placeHolder="Enter text" />;
//   return <input type="text" placeHolder="Enter text" maxLength="20" />;
//   return <input type="text" placeholder="Enter text" maxLength={20} required />;
//   return <textarea autoFocus={true} />;
// }

// function TextArea() {
// return <textarea autoFocus={true} />;
// return <textarea autoFocus />;
// return <textarea autoFocus={true} maxLength={5} rows={20} />;
// }

// ----- Stage 4 ------
// root.render(<MyInput />);
// root.render(<MyOthernput />);
// root.render(<TextArea />);

// Slide 12 -2
// function StyledComponent() {
//   const sectionStyle = {
//     color: "blue",
//     backgroundColor: "lightgray",
//     padding: "10px",
//     borderRadius: "5px",
//   };

//   return <section style={sectionStyle}>This is a styled section</section>;
// }

// Slide 12 - 3
function StyledComponent() {
  // Define keyframes for animation
  //   const keyframes = `
  //   @keyframes fadeInScale {
  //     0% {
  //       opacity: 0;
  //       transform: scale(0.5);
  //       background-color: lightgray;
  //     }
  //     50% {
  //       opacity: 0.5;
  //       transform: scale(1.2);
  //       background-color: lightblue;
  //     }
  //     100% {
  //       opacity: 1;
  //       transform: scale(1);
  //       background-color: lightgray;
  //     }
  //   }
  // `;
  // Create a style element with the keyframes defined
  // const styleSheet = document.styleSheets[0];
  // styleSheet.insertRule(keyframes, styleSheet.cssRules.length);
  // // Define styles for the div, including the animation
  // const sectionStyle = {
  //   color: "blue",
  //   padding: "10px",
  //   borderRadius: "5px",
  //   animation: "fadeInScale 3s ease-in-out infinite", // Apply animation
  // };
  return (
    // <section style={sectionStyle}>
    //   This is a styled section with animation
    // </section>
    <section className="animatedSection">
      This is a styled section with animation
    </section>
  );
}

// 2) Get a reference to the div with ID root
const element = document.getElementById("root");

// 3) Tell React to take control of that element
const root = ReactDOM.createRoot(element);
// Stage 6 ------
root.render(<StyledComponent />);
