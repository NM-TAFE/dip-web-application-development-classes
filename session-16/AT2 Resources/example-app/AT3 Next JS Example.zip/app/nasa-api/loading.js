"use client";

export default function Loading() {
    return (
        <div className="has-text-centered">
            <div className="loader is-loading"></div>
            <p>Loading data from NASA...</p>
        </div>
    );
}
