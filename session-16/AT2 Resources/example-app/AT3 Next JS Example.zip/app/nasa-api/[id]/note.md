# The dynamic route is removed so we can deploy the static site to github pages. - JohnR
