/** @type {import('tailwindcss').Config} */
module.exports = {
    content: [
        "./app/**/*.{js,jsx}",
        "./components/**/*.{js,jsx}",
        "./styles/**/*.{js,jsx}",
    ],
    theme: {
        extend: {},
    },
    plugins: [],
};
